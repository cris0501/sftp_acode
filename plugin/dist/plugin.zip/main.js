"use strict";(()=>{var T="com.cris.termux-fs",I="http://127.0.0.1:8765",z="dev-token",v=new Map,k=["node_modules","__pycache__",".git",".cache",".npm",".termux",".venv","venv",".env",".mypy_cache",".pytest_cache","build",".gradle"],M={js:"#f1e05a",mjs:"#f1e05a",jsx:"#61dafb",ts:"#3178c6",tsx:"#3178c6",py:"#3572a5",pyw:"#3572a5",html:"#e34c26",htm:"#e34c26",css:"#563d7c",scss:"#c6538c",less:"#1d365d",json:"#a3a3a3",yaml:"#cb171e",yml:"#cb171e",toml:"#9c4221",md:"#519aba",txt:"#888888",sh:"#89e051",bash:"#89e051",zsh:"#89e051",java:"#b07219",kt:"#A97BFF",dart:"#00B4AB",c:"#555555",cpp:"#f34b7d",h:"#555555",rs:"#dea584",go:"#00ADD8",rb:"#701516",php:"#4F5D95",sql:"#e38c00",db:"#e38c00",xml:"#0060ac",svg:"#ffb13b",png:"#a074c4",jpg:"#a074c4",jpeg:"#a074c4",gif:"#a074c4",webp:"#a074c4",ico:"#a074c4",zip:"#e6b800",tar:"#e6b800",gz:"#e6b800",pdf:"#ec2025",log:"#666666",env:"#ecd53f",gitignore:"#f54d27",dockerignore:"#2496ed",dockerfile:"#2496ed",makefile:"#427819"},O="var(--link-text-color, #6494e4)",w=[],b=null,l=[],u=null;async function g(a,t={}){let e=await fetch(I+a,{...t,headers:{Authorization:`Bearer ${z}`,"Content-Type":"application/json",...t.headers||{}}});if(!e.ok){let r=await e.text();throw new Error(`HTTP ${e.status}: ${r}`)}return e.json()}async function j(a,t,e){return g("/fs/create",{method:"POST",body:JSON.stringify({path:a,type:t,content:e||""})})}async function F(a){return g("/fs/delete",{method:"DELETE",body:JSON.stringify({path:a})})}function L(a,t){if(v.has(a)){let o=v.get(a);try{o.makeActive();return}catch{v.delete(a)}}let e=a.split("/").pop();acode.newEditorFile(e,{text:t.content,editable:!0,render:!0});let r=editorManager.activeFile,s=t.mtime;v.set(a,r),r.on("close",()=>{v.delete(a)}),r.save=async()=>{try{let o=r.session.getValue();await g("/fs/write",{method:"PATCH",body:JSON.stringify({path:a,content:o,mtime:s})}),s=(await g(`/fs/read?path=${encodeURIComponent(a)}`)).mtime,r.isUnsaved=!1,window.toast("Guardado en Termux",3e3)}catch(o){o.message.includes("409")?acode.alert("Conflicto","El archivo cambi\xF3 en el servidor."):acode.alert("Error al guardar",o.message)}}}function N(a){let t=a.toLowerCase(),e={dockerfile:"#2496ed",makefile:"#427819",".gitignore":"#f54d27",".env":"#ecd53f",license:"#d4a928","readme.md":"#519aba"};if(e[t])return e[t];let r=t.includes(".")?t.split(".").pop():"";return M[r]||"#888888"}var C=`
  .tfs {
    font-family: system-ui, sans-serif;
    font-size: 13px;
    color: var(--popup-text-color, #ccc);
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  .tfs-toolbar {
    display: flex;
    align-items: center;
    padding: 6px 8px;
    gap: 4px;
    border-bottom: 1px solid var(--border-color, #333);
    flex-shrink: 0;
  }
  .tfs-toolbar button, .tfs-root-actions button {
    background: none;
    border: none;
    color: var(--secondary-text-color, #aaa);
    font-size: 18px;
    cursor: pointer;
    padding: 4px 6px;
    border-radius: 4px;
    line-height: 1;
  }
  .tfs-toolbar button:active, .tfs-root-actions button:active {
    background: var(--button-active-color, #333);
  }
  .tfs-toolbar .spacer { flex: 1; }
  .tfs-toolbar .title {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--secondary-text-color, #aaa);
    font-weight: 600;
  }
  .tfs-content {
    flex: 1;
    overflow-y: auto;
  }
  .tfs-root {
    border-bottom: 1px solid var(--border-color, #222);
  }
  .tfs-root-header {
    display: flex;
    align-items: center;
    padding: 8px;
    cursor: pointer;
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    color: var(--popup-text-color, #ccc);
    gap: 4px;
  }
  .tfs-root-header:active {
    background: var(--button-active-color, #333);
  }
  .tfs-root-header .arrow {
    font-size: 10px;
    width: 16px;
    text-align: center;
    transition: transform 0.15s;
    color: var(--secondary-text-color, #aaa);
  }
  .tfs-root-header .arrow.open { transform: rotate(90deg); }
  .tfs-root-actions {
    margin-left: auto;
    display: flex;
    gap: 0;
  }
  .tfs-root-actions button { font-size: 14px; padding: 2px 5px; }
  .tfs-entries { display: none; }
  .tfs-entries.open { display: block; }
  .tfs-item {
    display: flex;
    align-items: center;
    padding: 3px 0;
    padding-right: 8px;
    cursor: pointer;
    gap: 6px;
    min-height: 26px;
    position: relative;
  }
  .tfs-item:active {
    background: var(--button-active-color, #333);
  }
  .tfs-icon {
    width: 18px;
    height: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    font-size: 15px;
  }
  .tfs-dir-arrow {
    width: 16px;
    font-size: 9px;
    text-align: center;
    color: var(--secondary-text-color, #888);
    flex-shrink: 0;
    transition: transform 0.15s;
  }
  .tfs-dir-arrow.open { transform: rotate(90deg); }
  .tfs-name {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 13px;
  }
  .tfs-children { display: none; }
  .tfs-children.open { display: block; }
  .tfs-empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 32px 16px;
    gap: 12px;
    color: var(--secondary-text-color, #888);
    text-align: center;
  }
  .tfs-empty-state button {
    padding: 8px 16px;
    background: var(--button-background-color, #444);
    color: var(--popup-text-color, #ccc);
    border: none;
    border-radius: 4px;
    font-size: 13px;
    cursor: pointer;
  }
  .tfs-loading {
    padding: 8px;
    padding-left: 32px;
    color: var(--secondary-text-color, #888);
    font-size: 12px;
    font-style: italic;
  }
`;async function y(a,t){let e=t==="dir"?"carpeta":"archivo",r=await acode.prompt(`Nombre del ${e}`,"","text",{placeholder:t==="dir"?"nueva-carpeta":"archivo.js"});if(!r)return;let s=a?`${a}/${r}`:r;try{if(await j(s,t),window.toast(`${e} creado`,2e3),t==="file"){let o=await g(`/fs/read?path=${encodeURIComponent(s)}`);L(s,o)}m()}catch(o){o.message.includes("409")?acode.alert("Error",`Ya existe: ${r}`):acode.alert("Error",o.message)}}async function S(a,t){let e=a.split("/").pop(),s=[`\u{1F5D1}\uFE0F Eliminar ${t?"la carpeta":"el archivo"}`,"\u274C Cancelar"],o=await acode.select(`${e}`,s),c=typeof o=="number"?s[o]:o;if(!(!c||c.startsWith("\u274C")))try{await F(a),window.toast("Eliminado",2e3),m()}catch(d){acode.alert("Error",d.message)}}async function _(a,t){let e=a.split("/").pop(),r=[];t&&(r.push("\u{1F4C4} Nuevo archivo aqu\xED"),r.push("\u{1F4C1} Nueva carpeta aqu\xED")),r.push("\u{1F5D1}\uFE0F Eliminar"),r.push("\u274C Cancelar");let s=await acode.select(e,r),o=typeof s=="number"?r[s]:s;!o||o.startsWith("\u274C")||(o.startsWith("\u{1F4C4}")?await y(a,"file"):o.startsWith("\u{1F4C1}")?await y(a,"dir"):o.startsWith("\u{1F5D1}\uFE0F")&&await S(a,t))}function m(){if(!u)return;if(l.length===0){u.innerHTML=`<style>${C}</style>
      <div class="tfs">
        <div class="tfs-empty-state">
          <div style="font-size:32px">\u{1F4C2}</div>
          <div>No hay carpetas abiertas</div>
          <button data-global="add">Abrir carpeta</button>
        </div>
      </div>`,u.onclick=t=>{t.target.closest('[data-global="add"]')&&$()};return}let a=`<style>${C}</style><div class="tfs">
    <div class="tfs-toolbar">
      <span class="title">Termux FS</span>
      <span class="spacer"></span>
      <button data-global="add" title="Abrir carpeta">+</button>
      <button data-global="refresh" title="Refrescar todo">\u21BB</button>
    </div>
    <div class="tfs-content scroll">`;l.forEach((t,e)=>{let r=t.name||t.path.split("/").pop()||"~",s=!t.collapsed;a+=`<div class="tfs-root" data-root-idx="${e}">
      <div class="tfs-root-header" data-action="toggle-root" data-idx="${e}">
        <span class="arrow ${s?"open":""}">\u25B6</span>
        <span>\u{1F4C2} ${r}</span>
        <span class="tfs-root-actions">
          <button data-action="new-file" data-idx="${e}" title="Nuevo archivo">\u{1F4C4}+</button>
          <button data-action="new-dir" data-idx="${e}" title="Nueva carpeta">\u{1F4C1}+</button>
          <button data-action="close-root" data-idx="${e}" title="Cerrar">\u2715</button>
        </span>
      </div>
      <div class="tfs-entries ${s?"open":""}" id="tfs-root-${e}">
        <div class="tfs-loading">Cargando...</div>
      </div>
    </div>`}),a+="</div></div>",u.innerHTML=a,l.forEach((t,e)=>{t.collapsed||A(e,t.path,document.getElementById(`tfs-root-${e}`),1)}),u.onclick=t=>{let e=t.target.closest("[data-action], [data-global]");if(!e)return;let r=e.dataset.global;if(r==="add"){$();return}if(r==="refresh"){m();return}let s=e.dataset.action,o=parseInt(e.dataset.idx);if(s==="toggle-root"){if(t.target.closest(".tfs-root-actions"))return;l[o].collapsed=!l[o].collapsed,m()}else s==="close-root"?(t.stopPropagation(),l.splice(o,1),m()):s==="new-file"?(t.stopPropagation(),y(l[o].path,"file")):s==="new-dir"&&(t.stopPropagation(),y(l[o].path,"dir"))}}async function A(a,t,e,r){try{let o=(await g(`/fs/list?path=${encodeURIComponent(t)}`)).filter(n=>!n.name.startsWith(".")&&!k.includes(n.name)).sort((n,i)=>n.type!==i.type?n.type==="dir"?-1:1:n.name.localeCompare(i.name));if(o.length===0){e.innerHTML='<div class="tfs-loading">Vac\xEDo</div>';return}let c=r*16,d="";for(let n of o){let i=t?`${t}/${n.name}`:n.name,h=n.type==="dir"?O:N(n.name);if(n.type==="dir"){let f=`tfs-dir-${i.replace(/[^a-zA-Z0-9]/g,"-")}`;d+=`<div>
          <div class="tfs-item" style="padding-left:${c}px"
               data-dir-toggle="${f}" data-dir-path="${i}"
               data-root="${a}" data-depth="${r+1}"
               data-ctx-path="${i}" data-ctx-dir="true">
            <span class="tfs-dir-arrow">\u25B6</span>
            <span class="tfs-icon" style="color:${h}">\u{1F4C1}</span>
            <span class="tfs-name">${n.name}</span>
          </div>
          <div class="tfs-children" id="${f}"></div>
        </div>`}else d+=`<div class="tfs-item" style="padding-left:${c+16}px"
                     data-file-open="${i}"
                     data-ctx-path="${i}" data-ctx-dir="false">
          <span class="tfs-icon">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="${h}">
              <path d="M3 1h6.5L13 4.5V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zm6 0v4h4"/>
            </svg>
          </span>
          <span class="tfs-name">${n.name}</span>
        </div>`}e.innerHTML=d;let p=null;e.addEventListener("touchstart",n=>{let i=n.target.closest("[data-ctx-path]");i&&(p=setTimeout(()=>{p=null,_(i.dataset.ctxPath,i.dataset.ctxDir==="true")},500))},{passive:!0}),e.addEventListener("touchend",()=>{p&&clearTimeout(p)},{passive:!0}),e.addEventListener("touchmove",()=>{p&&clearTimeout(p)},{passive:!0}),e.onclick=async n=>{n.stopPropagation();let i=n.target.closest("[data-dir-toggle]");if(i){let f=i.dataset.dirToggle,x=document.getElementById(f),E=i.querySelector(".tfs-dir-arrow");x.classList.contains("open")?(x.classList.remove("open"),E.classList.remove("open")):(x.classList.add("open"),E.classList.add("open"),x.dataset.loaded||(x.innerHTML='<div class="tfs-loading">Cargando...</div>',await A(parseInt(i.dataset.root),i.dataset.dirPath,x,parseInt(i.dataset.depth)),x.dataset.loaded="true"));return}let h=n.target.closest("[data-file-open]");if(h)try{let f=await g(`/fs/read?path=${encodeURIComponent(h.dataset.fileOpen)}`);L(h.dataset.fileOpen,f)}catch(f){acode.alert("Error",f.message)}}}catch(s){e.innerHTML=`<div class="tfs-loading">Error: ${s.message}</div>`}}async function $(){async function a(t){try{let s=(await g(`/fs/list?path=${encodeURIComponent(t)}`)).filter(n=>n.type==="dir"&&!n.name.startsWith(".")&&!k.includes(n.name)).sort((n,i)=>n.name.localeCompare(i.name)).map(n=>`\u{1F4C1} ${n.name}`);s.unshift("\u2705 Abrir este directorio"),t&&s.unshift("\u2B06\uFE0F ..");let o=await acode.select(`Termux: /${t||"~"}`,s);if(o==null)return;let c=typeof o=="number"?s[o]:o;if(!c)return;if(c==="\u2B06\uFE0F ..")return a(t.split("/").slice(0,-1).join("/"));if(c==="\u2705 Abrir este directorio"){if(l.some(n=>n.path===t)){window.toast("Ya est\xE1 abierto",2e3);return}l.push({path:t,name:t.split("/").pop()||"Home",collapsed:!1}),m();return}let d=c.replace(/^📁 /,""),p=t?`${t}/${d}`:d;return a(p)}catch(e){acode.alert("Error",e.message)}}a("")}acode.setPluginInit(T,(a,t,e)=>{b=acode.require("sideBarApps"),b.add("icon_terminal","termux-fs","Termux FS",s=>{u=s,s.style.height="100%",m()},!1,s=>{u=s,m()});let{commands:r}=editorManager.editor;r.addCommand({name:"termux-add-folder",description:"Termux: Abrir carpeta",exec:$}),w.push("termux-add-folder"),window.toast("Termux FS cargado",3e3)});acode.setPluginUnmount(T,()=>{let{commands:a}=editorManager.editor;w.forEach(t=>a.removeCommand(t)),w=[],b&&b.remove("termux-fs"),u=null,l=[],v=new Map});})();
